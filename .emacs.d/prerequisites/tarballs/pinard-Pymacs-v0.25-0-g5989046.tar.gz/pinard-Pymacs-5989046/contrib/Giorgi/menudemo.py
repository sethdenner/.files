# -*- coding: utf-8 -*-
import sys
import os.path
import string
from Pymacs import lisp


sys.path.append(".")


interactions = {}

def testVectors():
    # Test vectors
    # Returns something like ["a" "b"] which is a emacs lisp vector
    return ("a", "b")



def installPymacsMenu():
    pass


interactions[testVectors]=''
interactions[installPymacsMenu]=''
